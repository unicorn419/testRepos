﻿#include "pch.h"
#include "DPAlgo.h"
#include <algorithm>
#include <map>

using namespace std;
DPAlgo::DPAlgo()
{
}


DPAlgo::~DPAlgo()
{
}

int DPAlgo::maxSubMartix(vector<vector<int>> grid)
{
	int n, i, j, k, maxsubrec=0, maxsubarr;
	int *  arr = new int[grid.size()];
	maxsubrec = 0;
	for (i = 0;i < grid.size();i++)
	{
		memset(arr, 0, sizeof(arr));
		for (j = i;j < grid.size();j++)
		{
			for (k = 0;k < grid.size();k++)
				arr[k] += grid[j][k];
			maxsubarr = maxSubArray(arr, grid.size());
			maxsubrec = max(maxsubarr,maxsubrec);
		}
	}
	delete[] arr;
	return maxsubrec;

}

//b[i]=max(sum(0-i)) return max(b[i-1] + a[i],a[i])
int DPAlgo::maxSubArray(int * arr, int n)
{
	int i, b = 0, sum = 0;
	for (i = 0;i < n;i++)
	{
		if (b > 0)                // 若a[i]+b[i-1]会减小
			b += arr[i];        // 则以a[i]为首另起一个子段
		else
			b = arr[i];
		b = max(sum, b);
	}
	return sum;
}

int DPAlgo::maxOrMinPath(vector<vector<int>> grid)
{
	vector<vector<int>> dp(grid.size()+1, vector<int>(grid[0].size()+1, 0));
	for (int i = 0;i < grid.size();i++)
	{
		for (int j = 0;j < grid[i].size();j++)
		{
			dp[i + 1][j + 1] = max(dp[i][j + 1], dp[i + 1][j]) + grid[i][j];
			//dp[i + 1][j + 1] = min(dp[i][j + 1], dp[i + 1][j]) + grid[i][j];
		}
	}
	return dp[grid.size()][grid[0].size()];
}

int DPAlgo::maxValuePackage(int capacity, int goodsCount, vector<int>& weight, vector<int>& goodsValues)
{
	//dp[i][j] 可以使用j 空间的情况下 塞入0-i 的最大价值
	vector<vector<int>>dp(goodsCount+1,vector<int>(capacity+1,0));
	int maxVal = 0, minVal = 0;

	for (int i = 1; i <= goodsCount; i++) {
		for (int j = 1; j <= capacity; j++) {
			//dp[i - 1][j - weight[i]] 为前一个可放置物品的最大值 
			//dp[i - 1][j] 为前一个可放置物品当前最大值

			//假如可放入i 物品
			if (j >= weight[i])
				dp[i][j] = max(dp[i-1][j], dp[i][j - weight[i]] + goodsValues[i]);
			//如计算最小成本 ，此处改为min
			else
				//无法放置i物品,
				dp[i][j] = dp[i - 1][j];
		}
	}

	return dp[goodsCount][capacity];
}

int DPAlgo::minCoins(int money, vector<int>& coins)
{
	vector<vector<int>> dp(coins.size()+1, vector<int>(money+1, 0));
	for (int j = 1;j <= money;j++) dp[0][j] = INT_MAX;
	for (int i = 1;i <= coins.size();i++)
	{
		for (int j = 1;j <= money;j++)
		{
			if (j >= coins[i-1])
			{
				dp[i][j] = min(dp[i - 1][j], dp[i][j-coins[i-1]]+1) ;
			}
			else
			{
				dp[i][j] = dp[i - 1][j];
			}
		}
	}
	return dp[coins.size()][money];



}


vector<string> DPAlgo::popularNFeatures(int numFeatures, int topFeatures,
	vector<string> possibleFeatures,
	int numFeatureRequests,
	vector<string> featureRequests)
{
	vector<string> res;

	std::map<string, int> mapWords;
	for (int i = 0;i < numFeatures;i++) mapWords[possibleFeatures[i]] = 0;

	for (int i = 0;i < numFeatureRequests;i++)
	{
		std::map<string, int> mapOccus;
		string request = featureRequests[i];
		int  end = 0;
		while (end < request.size())
		{
			string word("");
			while (end < request.size() &&((request.at(end) >= 'a' && request.at(end) <= 'z') ||
				(request.at(end) >= 'A' && request.at(end) <= 'Z')))
			{
				if ((request.at(end) >= 'A' && request.at(end) <= 'Z'))
					word.push_back(request.at(end) - 'A' + 'a');
				else
					word.push_back(request.at(end));
				end++;
			}
			mapOccus[word]++;
			if (mapOccus[word] == 1)
				mapWords[word]++;

			end++;
		}
	}
	vector<vector<string>> result(numFeatures);
	for (auto iter = mapWords.begin();iter != mapWords.end();iter++)
	{
		result[iter->second].push_back(iter->first);
	}
	int index = numFeatures - 1;
	int count = 0;
	while (index > 0 && count < topFeatures)
	{
		for (int i = 0;i < result[index].size();i++)
		{
			res.push_back(result[index][i]);
			count++;
		}
		index--;
	}


	return res;

}
