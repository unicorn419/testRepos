#include "pch.h"
#include "TireTree.h"


TireTree::TireTree()
{
}


TireTree::~TireTree()
{
}
